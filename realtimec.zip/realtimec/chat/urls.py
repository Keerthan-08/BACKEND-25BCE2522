from django.urls import path
from .views import ChatHistoryView, ProfileUpdateView

urlpatterns = [
    path('history/<int:user_id>/', ChatHistoryView.as_view()),
    path('profile/', ProfileUpdateView.as_view()),
]