from rest_framework import generics, permissions
from django.db.models import Q
from django.contrib.auth import login, logout
from django.contrib.auth.forms import AuthenticationForm
from django.shortcuts import render, redirect
from django.views import View
from .models import Message
from .serializers import MessageSerializer, UserSerializer


class ChatHistoryView(generics.ListAPIView):
    """
    Get chat history between current user and another user
    """
    serializer_class = MessageSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        other_user_id = self.kwargs['user_id']
        return Message.objects.filter(
            (Q(sender=self.request.user) & Q(receiver_id=other_user_id)) |
            (Q(sender_id=other_user_id) & Q(receiver=self.request.user))
        ).order_by('timestamp')


class ProfileUpdateView(generics.RetrieveUpdateAPIView):
    """
    Get or update current user's profile
    """
    serializer_class = UserSerializer
    permission_classes = [permissions.IsAuthenticated]
    
    def get_object(self):
        return self.request.user


class LoginView(View):
    """
    Login page for users
    """
    def get(self, request):
        if request.user.is_authenticated:
            return redirect('chat_page')
        form = AuthenticationForm()
        return render(request, 'chat/login.html', {'form': form})
    
    def post(self, request):
        form = AuthenticationForm(data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            return redirect('chat_page')
        return render(request, 'chat/login.html', {'form': form})


class LogoutView(View):
    """
    Logout view
    """
    def get(self, request):
        logout(request)
        return redirect('login')


class ChatPageView(View):
    """
    Main chat page - requires authentication
    """
    def get(self, request):
        if not request.user.is_authenticated:
            return redirect('login')
        return render(request, 'chat/chat.html')