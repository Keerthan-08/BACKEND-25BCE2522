import json
from channels.generic.websocket import AsyncWebsocketConsumer
from channels.db import database_sync_to_async
from .models import Message
from django.contrib.auth.models import User


class ChatConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        # Get the user from scope (authenticated user)
        if not self.scope['user'].is_authenticated:
            await self.close()
            return

        self.other_user_id = self.scope['url_route']['kwargs']['user_id']
        self.current_user_id = self.scope['user'].id
        
        # Create a unique room name for this pair of users
        # Always use the same room name regardless of who initiates
        user_ids = sorted([int(self.current_user_id), int(self.other_user_id)])
        self.room_name = f'chat_{user_ids[0]}_{user_ids[1]}'
        
        print(f"User {self.scope['user'].username} (ID: {self.current_user_id}) connecting to room: {self.room_name}")
        
        # Join room group
        await self.channel_layer.group_add(
            self.room_name,
            self.channel_name
        )
        
        await self.accept()

    async def disconnect(self, close_code):
        # Leave room group
        if hasattr(self, 'room_name'):
            print(f"User disconnecting from room: {self.room_name}")
            await self.channel_layer.group_discard(
                self.room_name,
                self.channel_name
            )

    async def receive(self, text_data):
        # Receive message from WebSocket
        try:
            data = json.loads(text_data)
            message = data['message']
            
            print(f"Received message from {self.scope['user'].username}: {message}")
            
            # Save message to database
            await self.save_message(self.other_user_id, message)
            
            # Send message to room group (INCLUDING the sender)
            await self.channel_layer.group_send(
                self.room_name,
                {
                    'type': 'chat_message',
                    'message': message,
                    'sender_id': self.current_user_id,
                    'sender_username': self.scope['user'].username
                }
            )
            print(f"Message sent to room {self.room_name}")
            
        except Exception as e:
            print(f"Error in receive: {e}")

    async def chat_message(self, event):
        # Send message to WebSocket
        try:
            print(f"Sending message to client: {event['message']} from {event['sender_username']}")
            await self.send(text_data=json.dumps({
                'message': event['message'],
                'sender_id': event['sender_id'],
                'sender_username': event['sender_username']
            }))
        except Exception as e:
            print(f"Error in chat_message: {e}")

    @database_sync_to_async
    def save_message(self, receiver_id, content):
        try:
            receiver = User.objects.get(id=receiver_id)
            msg = Message.objects.create(
                sender=self.scope['user'],
                receiver=receiver,
                content=content
            )
            print(f"Message saved to database: {msg.id}")
            return msg
        except Exception as e:
            print(f"Error saving message: {e}")
            return None